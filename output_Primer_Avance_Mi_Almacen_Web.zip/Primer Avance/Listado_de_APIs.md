# Listado de APIs Identificadas - Sistema de Inventario "Mi Almacén Web"

## Endpoints Proyectados (Node.js + Express)

### Productos
- `GET /api/productos` - Obtiene el listado general de productos con sus nombres de categoría y proveedor.
- `GET /api/productos/:id` - Obtiene los detalles específicos de un producto por su ID.
- `POST /api/productos` - Crea y registra un nuevo producto en la base de datos.
- `PUT /api/productos/:id` - Actualiza los precios, stock mínimo o información de un producto.

### Categorías
- `GET /api/categorias` - Lista todas las categorías registradas.
- `POST /api/categorias` - Registra una nueva categoría de productos.

### Proveedores
- `GET /api/proveedores` - Obtiene el catálogo completo de proveedores.
- `POST /api/proveedores` - Agrega un nuevo proveedor al sistema.

### Movimientos de Inventario
- `GET /api/movimientos` - Consulta el historial completo de entradas y salidas.
- `POST /api/movimientos` - Registra una nueva entrada (E) o salida (S) vinculada al producto y usuario operador.
- `GET /api/productos/stock/calculado` - Calcula el stock actual por producto mediante la fórmula: `SUM(Entradas) - SUM(Salidas)`.

### Usuarios
- `GET /api/usuarios` - Obtiene la lista de operadores del almacén registrados.
