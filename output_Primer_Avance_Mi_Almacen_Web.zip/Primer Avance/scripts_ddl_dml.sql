-- ============================================================
-- BASE DE DATOS: Sistema de Inventario "Mi Almacén Web"
-- ARCHIVO: scripts_ddl_dml.sql
-- DESCRIPCIÓN: Creación de BD, Tablas (DDL), Restricciones y Datos de Prueba (DML)
-- ============================================================

-- ------------------------------------------------------------
-- 1. CREACIÓN Y SELECCIÓN DE LA BASE DE DATOS
-- ------------------------------------------------------------
DROP DATABASE IF EXISTS almacen_db;
CREATE DATABASE almacen_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE almacen_db;

-- ------------------------------------------------------------
-- 2. TABLAS INDEPENDIENTES (Sin llaves foráneas)
-- ------------------------------------------------------------

-- Tabla: Categorias
-- Almacena las categorías de los productos (ej. Electrónica, Limpieza, Alimentos)
CREATE TABLE categorias (
    id_categoria INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL UNIQUE,
    descripcion TEXT,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Tabla: Proveedores
-- Guarda la información de contacto de los proveedores de mercadería
CREATE TABLE proveedores (
    id_proveedor INT AUTO_INCREMENT PRIMARY KEY,
    nombre_proveedor VARCHAR(150) NOT NULL,
    telefono VARCHAR(20) NOT NULL,
    correo VARCHAR(100) NOT NULL UNIQUE,
    direccion TEXT NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Tabla: Usuarios
-- Operadores y administradores del sistema que registran movimientos
CREATE TABLE usuarios (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nombre_completo VARCHAR(150) NOT NULL,
    correo VARCHAR(100) NOT NULL UNIQUE,
    username VARCHAR(50) NOT NULL UNIQUE,
    rol ENUM('Administrador', 'Vendedor', 'Almacenero') NOT NULL DEFAULT 'Vendedor',
    estado ENUM('activo', 'inactivo') NOT NULL DEFAULT 'activo',
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 3. TABLAS DEPENDIENTES (Con llaves foráneas)
-- ------------------------------------------------------------

-- Tabla: Productos
-- Contiene el catálogo principal de productos del almacén
CREATE TABLE productos (
    id_producto INT AUTO_INCREMENT PRIMARY KEY,
    sku VARCHAR(50) NOT NULL UNIQUE,
    nombre VARCHAR(150) NOT NULL,
    descripcion TEXT,
    precio_compra DECIMAL(10,2) NOT NULL CHECK (precio_compra > 0),
    precio_venta DECIMAL(10,2) NOT NULL CHECK (precio_venta > 0),
    stock_minimo INT NOT NULL DEFAULT 5 CHECK (stock_minimo >= 0),
    estado ENUM('activo', 'inactivo') NOT NULL DEFAULT 'activo',
    id_categoria INT NOT NULL,
    id_proveedor INT NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Relaciones (Foreign Keys)
    CONSTRAINT fk_productos_categorias FOREIGN KEY (id_categoria) 
        REFERENCES categorias(id_categoria) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_productos_proveedores FOREIGN KEY (id_proveedor) 
        REFERENCES proveedores(id_proveedor) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Tabla: MovimientosInventario
-- Registra todas las entradas (E) y salidas (S) de mercadería
CREATE TABLE movimientos_inventario (
    id_movimiento INT AUTO_INCREMENT PRIMARY KEY,
    id_producto INT NOT NULL,
    tipo_movimiento ENUM('E', 'S') NOT NULL, -- 'E' = Entrada, 'S' = Salida
    cantidad INT NOT NULL CHECK (cantidad > 0),
    fecha_hora DATETIME DEFAULT CURRENT_TIMESTAMP,
    observaciones VARCHAR(255),
    id_usuario INT NOT NULL,
    
    -- Relaciones (Foreign Keys)
    CONSTRAINT fk_movimientos_productos FOREIGN KEY (id_producto) 
        REFERENCES productos(id_producto) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_movimientos_usuarios FOREIGN KEY (id_usuario) 
        REFERENCES usuarios(id_usuario) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- 4. SCRIPTS DML (INSERCIÓN DE DATOS DE PRUEBA)
-- ============================================================

-- Insertar Categorías
INSERT INTO categorias (nombre, descripcion) VALUES
('Electrónica', 'Dispositivos electrónicos, accesorios y equipos.'),
('Limpieza', 'Productos desinfectantes, jabones y artículos de aseo.'),
('Alimentos', 'Comestibles, bebidas y granos básicos.');

-- Insertar Proveedores
INSERT INTO proveedores (nombre_proveedor, telefono, correo, direccion) VALUES
('Distribuidora Tech S.A.', '9988-7766', 'contacto@techsa.com', 'Col. San José, Calle 3, Tegucigalpa'),
('Comercializadora El Sol', '8877-6655', 'ventas@elsol.hn', 'Bo. El Centro, San Pedro Sula'),
('Suministros Globales', '2233-4455', 'info@suministrosglobales.com', 'Parque Industrial, Choloma');

-- Insertar Usuarios
INSERT INTO usuarios (nombre_completo, correo, username, rol, estado) VALUES
('Carlos Mendoza', 'cmendoza@almacen.com', 'admin_carlos', 'Administrador', 'activo'),
('Ana Rodríguez', 'arodriguez@almacen.com', 'ana_ventas', 'Vendedor', 'activo'),
('Luis Gómez', 'lgomez@almacen.com', 'luis_almacen', 'Almacenero', 'activo');

-- Insertar Productos
INSERT INTO productos (sku, nombre, descripcion, precio_compra, precio_venta, stock_minimo, estado, id_categoria, id_proveedor) VALUES
('PROD-001', 'Mouse Inalámbrico USB', 'Mouse óptico ergonómico 1600 DPI', 120.00, 250.00, 10, 'activo', 1, 1),
('PROD-002', 'Detergente Multiusos 1L', 'Líquido desinfectante para pisos y superficies', 35.00, 60.00, 20, 'activo', 2, 2),
('PROD-003', 'Arroz Clasificado 5kg', 'Bolsa de arroz blanco grano entero', 80.00, 110.00, 15, 'activo', 3, 3);

-- Insertar Movimientos de Inventario
INSERT INTO movimientos_inventario (id_producto, tipo_movimiento, cantidad, observaciones, id_usuario) VALUES
(1, 'E', 50, 'Compra inicial a Distribuidora Tech S.A.', 1),
(2, 'E', 100, 'Ingreso de lote mensual', 3),
(3, 'E', 40, 'Compra de inventario base', 1),
(1, 'S', 5, 'Venta realizada en mostrador', 2),
(2, 'S', 12, 'Venta a cliente minorista', 2);
